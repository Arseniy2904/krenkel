package Urok_03;

public class Kontrol1 {
    public static void main(String[] args) {
        int numberA = 5;
        int numberB = 4;
        int numberC = 3;
        double numberF = 2;
        double numberR = 1;
        double sum = 0;
        for (int i = 1; i <= 1; i++) {
            sum = numberR + (numberR/ numberF) + (numberR / numberC) + (numberR / numberB) + (numberR / numberA);
            System.out.println("Итого равно: " + (sum));
        }


    }
}
