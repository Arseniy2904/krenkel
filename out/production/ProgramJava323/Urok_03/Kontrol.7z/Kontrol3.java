package Urok_03;

public class Kontrol3 {
    public static void main(String[] args) {
        int numberA = 3;
        int numberB = 5;
        int sum = 0;
        int sum1 = 0;
        int sum2 = 0;
        for (int i = 1; i <= 1; i++) {
            sum = 3;
            sum1 = 44;
            sum2 = 555;
            System.out.println("В итоге мы получаем: " + sum + sum1 + sum2);
        }
    }
}
