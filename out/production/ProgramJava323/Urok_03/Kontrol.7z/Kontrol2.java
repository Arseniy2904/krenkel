package Urok_03;

public class Kontrol2 {
    public static void main(String[] args) {
        int numberA = 3;
        int numberW = 4;
        int numberB = 5;
        int sum = 0;
        for (int i = 1; i <= 1; i++) {
            sum = (numberA * numberA) + (numberW * numberW) + (numberB * numberB);
            System.out.println("Итого получаем: " + (sum));

        }
    }
}
