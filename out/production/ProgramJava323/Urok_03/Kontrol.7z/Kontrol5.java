package Urok_03;

import java.util.Scanner;

public class Kontrol5 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Слушайте и отгадайте загадку:");
        System.out.println("Что это такое: синий, большой, с усами и полностью набит зайцами?");//
        //НЕ ЗНАЮ КАК ДЕЛАТЬ!!!

    }
}
