package Urok_03;

public class Kontrol4 {
    public static void main(String[] args) {
        int numberA = 11;
        boolean sum = numberA % 2 != 0;
        for (int i = 1; i <= 1; i++) {
            sum = (numberA % 2 != 0);
            System.out.println(" Число " + numberA + " является ЦЕЛЫМ!? " + sum + " - (верно) ");
        }
    }
}
