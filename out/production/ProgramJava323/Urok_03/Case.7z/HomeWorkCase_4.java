package Urok_03;

public class HomeWorkCase_4 {
    public static void Smartphone(String[] args) {
        long number = 893508533; // НЕ ПОНЯЛ ЗАДАНИЕ!

    }
}
