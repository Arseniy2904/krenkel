package Urok_03;

public class HomeWorkCase_3 {
    public static void main(String[] args) {
        int number1 = 33;
        switch (2) {
            case 1:
                System.out.println("Отрицательное");
                break;
            case 2:
                System.out.println("Положительное");
                break;
        }
        switch (2) {
            case 1:
                System.out.println("Чётное");
                break;
            case 2:
                System.out.println("Нечётное");
                break;
        }
        switch (1) {
            case 1:
                System.out.println("число");
                break;


        }
    }
}
