package Urok_03;

public class Array04 {
    public static void main(String[] args) {
        int[] array = {2, 4, 8, 16,};
        int a = 5;
        int number1 = 2;
        int sum = 0;
        for (int i = 0; i < array.length; i++) {
            sum = array[i] * number1;
            System.out.println("Массив степени двойки(2) будет выглядеть: " + sum);

        }

    }

}


