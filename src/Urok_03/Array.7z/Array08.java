package Urok_03;

public class Array08 {
    public static void main(String[] args) {
        //String firstName =

    }
}
