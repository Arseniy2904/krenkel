package Urok_03;

import java.util.Scanner;

public class Work7_if {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int month = 6;
        if (month > 0 && month <= 1) {
            System.out.println("Зима: Январь");

        } else if (month > 1 && month <= 2) {
            System.out.println("Зима: Февраль");
        } else if (month > 2 && month <= 3) {
            System.out.println("Весна: Март");
        } else if (month > 3 && month <= 4) {
            System.out.println("Весна: Апрель");
        } else if (month > 4 && month <= 5) {
            System.out.println("Весна: Май");
        } else if (month > 5 && month <= 6) {
            System.out.println("Лето: Июнь");
        } else if (month > 6 && month <= 7) {
            System.out.println("Лето: Июль");
        } else if (month > 7 && month <= 8) {
            System.out.println("Лето: Август");
        } else if (month > 8 && month <= 9) {
            System.out.println("Осень: Сентябрь");
        } else if (month > 9 && month <= 10) {
            System.out.println("Осень: Октябрь");
        } else if (month > 10 && month <= 11) {
            System.out.println("Осень: Ноябрь");
        } else if (month > 11 && month <= 12) {
            System.out.println("Зима: Декабрь");


        }

    }
}
