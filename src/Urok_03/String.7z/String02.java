package Urok_03;

public class String02 {
    public static void main(String[] args) {
        String array = "+79155673426";
        System.out.println(array.startsWith("+79155673426"));
        System.out.println(array.startsWith("+79155673425"));
    }
}
