package Urok_03;

public class String05 {
    public static void main(String[] args) {
        String stroke = "Шумоизоляция";
        System.out.println(stroke.indexOf((char"o", "и", "я"));
        // ?

    }
}
