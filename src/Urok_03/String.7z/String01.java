package Urok_03;

import java.util.Arrays;

public class String01 {
    public static void main(String[] args) {
        String stroke = "Окончание";
        char[] array = stroke.toCharArray();
        for (int i = 0; i < args.length; i++) {
        }
        System.out.println(Arrays.toString(array));
    }

}
