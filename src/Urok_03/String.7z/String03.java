package Urok_03;

import java.sql.SQLOutput;
import java.util.Arrays;

public class String03 {
    public static void main(String[] args) {
        String stroke = "Привет";
        System.out.println("Было:" + stroke);
        String charStroke = new String(new char[]{'т', 'е', 'в', 'и', 'р', 'П'});
        System.out.println("И получаем в зеркальном виде: " + charStroke);



    }
}
