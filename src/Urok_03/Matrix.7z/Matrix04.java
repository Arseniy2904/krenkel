package Urok_03;

import javax.xml.parsers.SAXParser;

public class Matrix04 {
    public static void main(String[] args) {
        int[][] matrix = {
                {1, 2, 3},
                {4, 5, 6,}
        };
        System.out.println("Второе по величине число: ");
        System.out.println(getMax(matrix));
    }

    private static int getMax(int[][] matrix) {
        int max = matrix[0][0];
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix.length; j++) {
                if (max < matrix[i][j]) {
                    if (matrix[i][j] < 6)
                        max = matrix[i][j];
                }

            }

        }
        return max;
    }
}
