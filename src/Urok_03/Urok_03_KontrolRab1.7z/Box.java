package Urok_03;

public class Box {
    double width;
    double height;
    double depth;
    double volume = width * height * depth;
}
