package Urok_03;

public class Kontrol_02 {
    public static void main(String[] Args) {
        int A = 1;
        int B = 2;
        int C = 3;
        System.out.println("Старые значения переменных: A = " + A +
                " , B = " + B +
                " , C = " + C +
                ";");

        int A1 = (A + 2);
        int B1 = (B - 1);
        int C1 = (C - 1);
        System.out.println("Новые значения переменных после изменения, которое дано в условии: A = " + A1 +
                ", B = " + B1 +
                ", C = " + C1 +
                ";");

    }
}
