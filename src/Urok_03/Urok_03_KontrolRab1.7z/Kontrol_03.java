package Urok_03;

public class Kontrol_03 {
    public static void main(String[] Args) {
        int numberOne = 493;
        String fore = "4", nine = "9", three = "3";
        String str = String.format(
                "Число 493 наоборот равно: %s%s%s",
                three,
                nine,
                fore


        );
        System.out.println(str);
    }
}
