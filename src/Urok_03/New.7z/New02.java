package Urok_03;

public class New02 {
    public static void main(String[] args) {
        String[] array = {"Арсений", "Дима", "Валера", "Ева"};
        int sum = 0;
        for (int i = 0; i <= 0; i++) {
            for (int j = 1; j <= 1; j++) {
                for (int k = 2; k <= 2; k++) {
                    for (int l = 3; l <= 3; l++) {
                        //(array[j] < array[i]) {
                            System.out.println(" слово Арсений самое большое ");
                        }
                    }
                } // затрудняюсь в задании!!!

            }

        }
    }


