package Urok_03;

public class Main04 {
    public static void main(String[] Args) {
        int a = 6; // значение угла в радианах
        double result = 57.29; // градусов в одном радиане
        double result1 = (a * result);
        System.out.println("Значение угла (a) в градусах составит = " + result1);


    }
}
