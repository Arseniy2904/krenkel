package Urok_03;

public class main02 {
    public static void main(String[] Args) {
       int numberOne = 15;
        int numberTwo = 25;
        int answer = (( numberOne + numberTwo ) / 2);
        System.out.println("Среднее арифметическое чисел " + numberOne + " и " + numberTwo + " равно " + answer);
    }
}
