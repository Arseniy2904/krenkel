package Urok_03;

public class Appel {
    String name;
    String nickname;
    String weight;

    public void printAppel() {
        System.out.println(
                "Животное" +
                        "Название-" + name + ";" +
                        "Кличка-" + nickname + ";" +
                        "Вес=" + weight

        );


    }

}
