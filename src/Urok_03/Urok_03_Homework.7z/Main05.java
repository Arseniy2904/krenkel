package Urok_03;

public class Main05 {
    public static void main(String[] Args) {
        int numberone = 17; // изначальное число
        String one = "1", seven = "7";
        String str = String.format(
                "Это цифра 17 наоборот: %s%s",
                seven,
                one

        );
        System.out.println(str);
    }

}
