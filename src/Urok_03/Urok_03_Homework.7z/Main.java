package Urok_03;

public class Main {
    public static void main(String[] args) {
        Appel appel = new Appel();
        appel.name = "Собака";
        appel.weight = "3500";
        appel.nickname = "Босс";
        appel.printAppel();


    }
}
