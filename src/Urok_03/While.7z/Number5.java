package Urok_03;

public class Number5 {
    public static void main(String[] args) {
        int number1 = 1;
        int number2 = 20;
        while (number1 < number2) {
            number1++;
            if (number1 % 2 == 0) {
                System.out.println("Четные числа: " + number1);
            }
        }
    } // НЕ ПОНИМАЮ, КАК СОВМЕСТИТЬ ВСЁ В ОДНУ!!! И ЧЁТНОСТЬ И ДЕЛЕНИЕ НА 4 И ЦИФРУ 19 КАК В ЗАДАНИИ
}




