package Urok_03;

public class HomeWork1 {
    public static void main(String[] args) {
        int number1 = 7;
        int sum = 0;
        for (int i = 1; i <= 1; i++) {
            for (int j = 2; j <= 2; j++) {
                for (int k = 3; k <= 3; k++) {
                    for (int t = 4; t <= 4; t++) {
                        for (int r = 5; r <= 5; r++) {
                            for (int e = 6; e <= 6; e++) {
                                for (int w = 7; w <= 7; w++) {
                                    sum = i * j * k * t * r * e * w;
                                    System.out.println("Факториал числа 7 равен = " + i + "*" + j +
                                            "*" + k + "*" + t + "*" + r + "*" + e + "*" + w + " и равен = " + sum);
                                    // НЕ ПОНЯЛ КАК ДЕЛАТЬ!!!//                                }
                                }

                            }
                        }
                    }
                }
            }
        }
    }
}
